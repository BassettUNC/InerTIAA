<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.0" name="PokeTile" tilewidth="32" tileheight="32" tilecount="3200" columns="80">
 <image source="PokeTile.png" width="2560" height="1280"/>
</tileset>
