import arcade
import arcade.gui
import tiaaGame.constants as constants

class RetireView(arcade.View):

    def __init__(self):
        super().__init__()

        self.manager = arcade.gui.UIManager()

        self.v_boxL = arcade.gui.UIBoxLayout()
        self.v_boxR = arcade.gui.UIBoxLayout()

        fouronek_button = arcade.gui.UIFlatButton(text="401k", width=200)
        self.v_boxL.add(fouronek_button.with_space_around(bottom=50, left=120, top=180))
        fouronek_button.on_click = self.on_click_fouronek

        